import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

//package main.fr.ut2j.m1ice.ootesting;

@RunWith (MockitoJUnitRunner.class)
public interface ITranslation {
	double getTx();

	double getTy();
}
